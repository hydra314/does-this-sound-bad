# does-this-sound-bad
A simple language created in Haskell by Blake Le, Cameron Kocher, and Robert Yelas.

Compile using ghci: *ghci doesthissoundbad.hs*
